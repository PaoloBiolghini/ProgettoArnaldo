package it.unibs.fp.planetariumm;

public class Collisione 
{

	public static boolean collisione( Stella star )
	{
		
		int i , j , k , t ;
		
		double raggio1 , raggio2 , distanzaCentri ;
		
		boolean result = false ;
		
		for ( i = 0 ; i < star.getPianeti().size() - 1 ; i++ )
		{
			
			raggio1 = star.getPianeti().get(i).distanzaEstraneo(star); // distanza pianeta stella 
			
			for ( j = i + 1 ; j < star.getPianeti().size() ; j++ )
			{
				
				if ( star.getPianeti().get(i).distanzaEstraneo(star) == star.getPianeti().get(j).distanzaEstraneo(star))
				{
					result = true ;
				}
				
				for ( k = 0 ; k < star.getPianeti().get(j).getLune().size() ; k++ )
				{
					
					raggio2 = star.getPianeti().get(j).getLune().get(k).distanzaEstraneo(star.getPianeti().get(j)); // luna e suo pianeta
					
					distanzaCentri = star.distanzaEstraneo(star.getPianeti().get(j)); // stella - pianeta
					
					if ( distanzaCentri > Math.abs( raggio1 - raggio2 ) && distanzaCentri < (raggio1 + raggio2) )
					{
						result = true ;
					}
					if ( (raggio1 + raggio2) == distanzaCentri )
					{
						result = true ;
					}
					
				}
				
			}
					
		}
		
		for ( i = 0 ; i < star.getPianeti().size() ; i++ )
		{
			for ( j = 0 ; j < star.getPianeti().get(i).getLune().size() ; j++ )
			{
				if ( star.getPianeti().get(i).getLune().get(j).distanzaEstraneo(star.getPianeti().get(i)) == star.distanzaEstraneo( star.getPianeti().get(i))) // distanza luna-pianeta e distanza stella pianeta
				{
					result = true ;
				}
				
				raggio1 = star.getPianeti().get(i).getLune().get(j).distanzaEstraneo(star.getPianeti().get(i)) ; // distanza satellite e pianeta
				
				for ( k = i + 1 ; k < star.getPianeti().size() ; k++ )
				{
					for ( t = 0 ; t < star.getPianeti().get(k).getLune().size() ; t++ )
					{
						
						raggio2 = star.getPianeti().get(k).getLune().get(t).distanzaEstraneo(star.getPianeti().get(k)) ; // distanza satelliti pianeti
						
						distanzaCentri = star.getPianeti().get(i).distanzaEstraneo( star.getPianeti().get(k) ); // centro (pianeti)
						
						if ( distanzaCentri > Math.abs( raggio1 - raggio2 ) && distanzaCentri < (raggio1 + raggio2) )
						{
							result = true ;
						}
						if ( (raggio1 + raggio2) == distanzaCentri )
						{
							result = true ;
						}
						
					}
					
				}
				
			}
			
		}
		
		return result ;
	}
	
}
