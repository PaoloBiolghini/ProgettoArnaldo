package it.unibs.fp.planetariumm;

public class Luna extends CorpoCeleste 
{

	public Luna(String _codiceID, double _massa, double _x, double _y) 
	{
		
		super(_codiceID, _massa, _x, _y);
		
	}
	
}