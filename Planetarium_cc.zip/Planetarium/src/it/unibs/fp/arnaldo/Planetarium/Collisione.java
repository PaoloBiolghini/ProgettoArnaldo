package it.unibs.fp.arnaldo.Planetarium;


public class Collisione 
{

	public static boolean collisione( Stella star )
	{
		
		int i , j , k , t ;
		
		double raggio1 , raggio2 , distanzaCentri ;
		
		boolean result = false ;
		
		/// ciclo  che confronta ogni pianeta dell'array list di pianeti della stella con tutti gl altri pianeti e i loro satelliti
		
		for ( i = 0 ; i < star.getPianeti().size() - 1 ; i++ )
		{
			
			raggio1 = star.getPianeti().get(i).distanzaEstraneo(star); // distanza pianeta stella 
			
			for ( j = i + 1 ; j < star.getPianeti().size() ; j++ )
			{
				
				if ( raggio1 == star.getPianeti().get(j).distanzaEstraneo(star)) // confronta restituisce true se i due pianeti sono sulla stessa orbita
				{
					result = true ; // forse non necessario
				}
				
				if ( !(star.getPianeti().get(j).getLune().isEmpty()) ) // il pianeta 2 ha delle lune , confronta il pianeta1 precedente con tutte le lune
				{
					
					for ( k = 0 ; k < star.getPianeti().get(j).getLune().size() ; k++ )
					{
						
						raggio2 = star.getPianeti().get(j).getLune().get(k).distanzaEstraneo(star.getPianeti().get(j)); // luna e suo pianeta
						
						distanzaCentri = star.distanzaEstraneo(star.getPianeti().get(j)); // stella - pianeta
						
						if ( distanzaCentri > Math.abs( raggio1 - raggio2 ) && distanzaCentri < (raggio1 + raggio2) ) // se la condizione � soddisfatta significa che le circonferenze sono secanti e la collisione � possibile
						{
							result = true ;
						}
						if ( (raggio1 + raggio2) == distanzaCentri ) // se la condizione � soddisfatta le circonferenze sono tangenti e quindi collisione possibile
						{
							result = true ;
						}
						
					}
					
				}
				
			}
					
		}
		
		// ciclo che confronta ogni luna con ogni luna di ogni altro pianeta
		
		for ( i = 0 ; i < star.getPianeti().size() ; i++ )
		{
			
			if ( !(star.getPianeti().get(i).getLune().isEmpty()) ) // se possiede lune 
			{
				
				for ( j = 0 ; j < star.getPianeti().get(i).getLune().size() ; j++ )
				{
					
					raggio1 = star.getPianeti().get(i).getLune().get(j).distanzaEstraneo(star.getPianeti().get(i)) ; // distanza satellite e pianeta
					
					if ( raggio1 == star.distanzaEstraneo( star.getPianeti().get(i))) // controlla se la traiettoria del satellite interferisce con la stella
					{
						result = true ;
					}
					
					for ( k = i + 1 ; k < star.getPianeti().size() ; k++ ) // pianeta successivo
					{
						
						// confronta il satellite in esame col pianeta
						
						raggio2 = star.distanzaEstraneo(star.getPianeti().get(k));
						
						distanzaCentri = star.distanzaEstraneo(star.getPianeti().get(i));
						
						if ( distanzaCentri > Math.abs( raggio1 - raggio2 ) && distanzaCentri < (raggio1 + raggio2) )
						{
							result = true ;
						}
						
						if ( (raggio1 + raggio2) == distanzaCentri )
						{
							result = true ;
						}
						
						
						if (!(star.getPianeti().get(k).getLune().isEmpty())) // se il pianeta ha satelliti confronta ognuna di essi con il satellite preso in esame del pianeta precedente
						{
							
							for ( t = 0 ; t < star.getPianeti().get(k).getLune().size() ; t++ ) // 
							{
								
								raggio2 = star.getPianeti().get(k).getLune().get(t).distanzaEstraneo(star.getPianeti().get(k)) ; // distanza satellite e pianeta
								
								distanzaCentri = star.getPianeti().get(i).distanzaEstraneo( star.getPianeti().get(k) ); // centri delle circonferenze (pianeti)
								
								if ( distanzaCentri > Math.abs( raggio1 - raggio2 ) && distanzaCentri < (raggio1 + raggio2) )
								{
									result = true ;
								}
								
								if ( (raggio1 + raggio2) == distanzaCentri )
								{
									result = true ;
								}
								
							}
							
						}
						
					}
					
				}
				
			}
	
		}
		
		return result ;
		
	}
	
}

