package it.unibs.fp.arnaldo.Planetarium;
/**
* @author christian garcia
*
*/

public class Luna extends CorpoCeleste {
	
	private final static String grado="luna";
	
	public Luna(String _codiceID, double _massa, double _x, double _y) {
		super(_codiceID, _massa, _x, _y);
		
	}
	
	public String getGrado() {
		return grado;
	}
	
	
}
