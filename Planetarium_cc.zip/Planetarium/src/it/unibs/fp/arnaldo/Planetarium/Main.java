package it.unibs.fp.arnaldo.Planetarium;
import it.unibs.fp.mylib.InputDati;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	private static ArrayList<Stella> listastelle = new ArrayList<Stella>();
	private static ArrayList<String> listaid=new ArrayList<String>();
	static Scanner scanner=new Scanner(System.in);
	
	public static void main(String[] args) {
		 Rotta distanza=new Rotta();
		 
		System.out.println("Benvenuti nel programma della classificazione universale");
		boolean controllo=true;
		while(controllo)
		{
			System.out.println("Menu:");
			System.out.println("1 per inserire nuovi elementi");
			System.out.println("2 per cercare corpi celesti");
			System.out.println("3 per avere informazioni relative a corpi celesti");
			System.out.println("4 per cancellare elementi dal sistema");
			System.out.println("5 per calcolare il centro di massa");
			System.out.println("6 per quittare");
			System.out.println("7 per calcolare la rotta");
			int scelta=InputDati.leggiIntero("", 1, 7);
			
			
			
			switch(scelta)
			{
			case 1: inserimento();break;
			case 2: ricerca(); break;
			case 3: getinfo(); break;
			case 4: eliminazione();break;
			case 5: break;
			case 6: controllo=false; break;
			case 7: distanza.calcola(listastelle); break;
			default: System.out.println("Scelta non trovata, inserire una scelta possibile"); break;
			}
			
		}
		
		System.out.println("Grazie per aver usato il planetarium.\n alla prossima volta");
	

	}
	
	//submenu inserimento corpi celesti
	public static void inserimento()
	{
		int scelta;
		do {
			
			System.out.println("immetti:");
			System.out.println("1 per inserire una stella");
			System.out.println("2 per inserire un pianeta");
			System.out.println("3 per inserire una luna");
			System.out.println("4 per tornare al menu");
			
			scelta=InputDati.leggiIntero("", 1, 4);
			
			switch(scelta)
			{
			case 1: inserimentostella(); break;
			case 2: inserimentopianeta(); break;
			case 3: inserimentoluna();   break;
			case 4: System.out.println("sarai reindirizzato al menu");break;
			default:  break;
			}
			
		}while(scelta<1||scelta>4);
		
		
		
	}
	
	
	public static void inserimentostella()
	{
		//inserimento dati stella
		
		String nome=InputDati.leggiStringaNonVuota("Nome: ");
				
		double massa=InputDati.leggiDoubleConMinimo("Massa:", 0);
		
		System.out.println("Inserisci la posizione");
		
		double x=InputDati.leggiDouble("x: ");
		
		double y=InputDati.leggiDouble("y: ");
		
		//controllo sul id
		if(!listaid.contains(nome))
		{
			Stella s=new Stella(nome,massa,x,y);
			listastelle.add(s);
			listaid.add(nome);
			
		}else {
			
			int scelta=InputDati.leggiIntero("nome non valido:  \n inserire:\n 1 per inesrirne uno nuovo \n qualsiasi numero per tornare al menu ");
			boolean controllo=false;
			
			if(scelta==1)
			 controllo=true;
			
			while(controllo)
			{
				
				nome=InputDati.leggiStringaNonVuota(" nome della stella");
				if(!listaid.contains(nome) )
				{
					Stella s=new Stella(nome,massa,x,y);
					listastelle.add(s);
					listaid.add(nome);
					controllo=false;
				}else {
					
					scelta=InputDati.leggiIntero("nome non valido:  \n inserire:\n 1 per inesrirne uno nuovo \n qualsiasi numero per tornare al menu ");
					if(scelta!=1)controllo=false;
				}
			}
		}
		
	}
	
	public static void inserimentopianeta()
	{
		if(listastelle.isEmpty())
		{
			System.out.println("\n� necessario inserire prima la stella presente nel sistema\n");
		}else
		{
			System.out.println("scegli il sistema cercato in base alla stella presente:");
			for(int i=0;i<listastelle.size();i++)
			{
				System.out.println("   "+i+" per il sistema di "+listastelle.get(i).getCodiceID());
			}
			
			System.out.println("   "+ listastelle.size() +" per tornare al menu");
			int sistema=InputDati.leggiIntero("", 0, listastelle.size());
			
			//inserimento dati pianeta
			if(sistema!=listastelle.size())
			{
				String nome=InputDati.leggiStringaNonVuota("Nome: ");
				
				double massa=InputDati.leggiDoubleConMinimo("Massa:", 0);
				
				System.out.println("Inserisci la posizione");
				
				double x=InputDati.leggiDouble("x: ");
				
				double y=InputDati.leggiDouble("y: ");
				
				//controllo sull'id
				if(!listaid.contains(nome))
				{
					Pianeta p=new Pianeta(nome,massa,x,y);
					listastelle.get(sistema).addPianeta(p);
					listaid.add(nome);
					
				}else {
					
					int scelta=InputDati.leggiIntero("nome non valido:  \n inserire:\n 1 per inesrirne uno nuovo \n qualsiasi numero per tornare al menu ");
					boolean controllo=false;
					
					if(scelta==1)
					 controllo=true;
					
					while(controllo)
					{
						
						nome=InputDati.leggiStringaNonVuota(" nome:");
						if(!listaid.contains(nome) )
						{
							Pianeta p=new Pianeta(nome,massa,x,y);
							listastelle.get(sistema).addPianeta(p);
							listaid.add(nome);
							controllo=false;
						}else {
							
							scelta=InputDati.leggiIntero("nome non valido:  \n inserire:\n 1 per inesrirne uno nuovo \n qualsiasi numero per tornare al menu ");
							if(scelta!=1)controllo=false;
						}
					}
				}
			}	
		}
	}
	
	public static void inserimentoluna()
	{
		if(listastelle.isEmpty())
		{
			System.out.println("\n� necessario inserire prima la stella presente nel sistema\n");
		}else
		{
			System.out.println("scegli il sistema cercato in base alla stella presente:");
			for(int i=0;i<listastelle.size();i++)
			{
				System.out.println("   "+i+" per il sistema di "+listastelle.get(i).getCodiceID());
			}
			
			System.out.println("   "+ listastelle.size() +" per tornare al menu");
			int sistema=InputDati.leggiIntero("", 0, listastelle.size());
			
			if(sistema!=listastelle.size())
			{
				if(!listastelle.get(sistema).getPianeti().isEmpty())
				{
					
					System.out.println("Inserisci il pianeta a cui appartiene il satellite");
					for(int i=0;i<listastelle.get(sistema).getPianeti().size();i++)
					{
						System.out.println("   "+i+" per il Pianeta di "+listastelle.get(sistema).getPianeti().get(i).getCodiceID());
					}
					System.out.println("   "+ listastelle.get(sistema).getPianeti().size() +" per tornare al menu");
					
					int pianeta=InputDati.leggiIntero("", 0, listastelle.get(sistema).getPianeti().size());
					
					if(pianeta!=listastelle.get(sistema).getPianeti().size())
					{
						
						String nome=InputDati.leggiStringaNonVuota("Nome: ");
						
						double massa=InputDati.leggiDoubleConMinimo("Massa:", 0);
						
						System.out.println("Inserisci la posizione");
						
						double x=InputDati.leggiDouble("x: ");
						
						double y=InputDati.leggiDouble("y: ");
						
						if(!listaid.contains(nome))
						{
							Luna l=new Luna(nome,massa,x,y);
							listastelle.get(sistema).getPianeti().get(pianeta).addLuna(l);
							listaid.add(nome);
							
						}else {
							
							int scelta=InputDati.leggiIntero("nome non valido:  \n inserire:\n 1 per inesrirne uno nuovo \n qualsiasi numero per tornare al menu ");
							boolean controllo=false;
							
							if(scelta==1)
							 controllo=true;
							
							while(controllo)
							{
								
								nome=InputDati.leggiStringaNonVuota(" nome:");
								if(!listaid.contains(nome) )
								{
									Luna l=new Luna(nome,massa,x,y);
									listastelle.get(sistema).getPianeti().get(pianeta).addLuna(l);
									listaid.add(nome);
									controllo=false;
								}else {
									
									scelta=InputDati.leggiIntero("nome non valido:  \n inserire:\n 1 per inesrirne uno nuovo \n qualsiasi numero per tornare al menu ");
									if(scelta!=1)controllo=false;
								}
							}
						}
						
						
					}
					
				}else {
					System.out.println("� necessario inserire un pianeta nel sistema prima di inserire una luna");
				}
			}
		}
	}
	
	
	public static void eliminazione()
	{
		System.out.println("Inserire:");
		System.out.println("   1 per cancellare un pianeta");
		System.out.println("   2 per cancellare una luna");
		System.out.println("   3 per tornare al menu");
		
		int eliminazione=InputDati.leggiIntero("", 1, 3);
		
		if(eliminazione!=3)
		{
			System.out.println("sai la locazione del corpo?");
			int sceltaloc=InputDati.leggiIntero("0 per si\n 1 per no",0,1);
			if(sceltaloc==1)
			{
				ricerca();
			}
			
			System.out.println("scegli il sistema cercato in base alla stella presente:");
			for(int i=0;i<listastelle.size();i++)
			{
				System.out.println("   "+i+" per il sistema di "+listastelle.get(i).getCodiceID());
			}
			
			System.out.println("   "+ listastelle.size() +" per tornare al menu");
			int sistema=InputDati.leggiIntero("", 0, listastelle.size());
			
			if(sistema!=listastelle.size())
			{
				if(eliminazione==1)
				{
				System.out.println("Inserisci il pianeta a cui appartiene il satellite");
				for(int i=0;i<listastelle.get(sistema).getPianeti().size();i++)
				{
					System.out.println("   "+i+" per il Pianeta di "+listastelle.get(sistema).getPianeti().get(i).getCodiceID());
				}
				System.out.println("   "+ listastelle.get(sistema).getPianeti().size() +" per tornare al menu");
				
				int pianeta=InputDati.leggiIntero("", 0, listastelle.get(sistema).getPianeti().size());
				if(pianeta!=listastelle.get(sistema).getPianeti().size())
				{
					listaid.remove(listastelle.get(sistema).getPianeti().get(pianeta).getCodiceID());
					listastelle.get(sistema).getPianeti().remove(pianeta);
					
				}
					
				}
			}
		}
	}
	
	//fa solamente il print del percorso
	public static void ricerca()
	{
		String nome=InputDati.leggiStringa("NomeCercato: ");
		if(!listaid.contains(nome))
		{
			System.out.println("Questo elemento non esiste");
		}else {
			for(Stella s:listastelle)
			{
				if(s.getCodiceID().equals(nome))
				{
					System.out.println("il corpo cercato � una stella");
				}else {
					for(Pianeta p:s.getPianeti())
					{
						if(p.getCodiceID().equals(nome))
						{
							System.out.println("il corpo cercato � un pianeta del sistema di "+s.getCodiceID());
						}else
						{
							for(Luna l:p.getLune())
							{
								if(l.getCodiceID().equals(nome))
								{
									System.out.println("il corpo cercato � una luna del pianta "+p.getCodiceID()+" del sistema di"+s.getCodiceID());
								}
							}
						}
					}
				}
				
			}
		}
	}
	
	//funzione che restituisce una lista contenente il percorso
	public static ArrayList<String> getpercorso()
	{
		ArrayList<String> lista= new ArrayList<String>();
		String nome=InputDati.leggiStringa("NomeCercato: ");
		if(listaid.contains(nome))
	 {
			for(Stella s:listastelle)
			{
				if(s.getCodiceID().equals(nome))
				{
					lista.add(nome);
				}else {
					for(Pianeta p:s.getPianeti())
					{
						if(p.getCodiceID().equals(nome))
						{
							
							lista.add(s.getCodiceID());
							lista.add(nome);
						}else
						{
							for(Luna l:p.getLune())
							{
								if(l.getCodiceID().equals(nome))
								{
									lista.add(s.getCodiceID());
									lista.add(p.getCodiceID());
									lista.add(nome);
								}
							}
						}
					}
				}
				
			}
		}
		return lista;
	}
	
	public static void getinfo()
	{
		System.out.println("Inserisci:");
		System.out.println("   1 dato un pianeta avere la lista dei satelliti");
		System.out.println("   2 dato un satellite avere il percorso ");
		System.out.println("   3 per tornare al menu");
		
		int scelta=InputDati.leggiIntero("", 1, 3);
		switch(scelta)
		{
		case 1: 
			
			ArrayList<String> perc=getpercorso();
			if(perc.size()==2)
			{
				for(Stella s:listastelle)
				{
					for(Pianeta p:s.getPianeti())
					{
						if(p.getCodiceID()==perc.get(1))
						{
							for(Luna l:p.getLune())
							{
								System.out.println(l.getCodiceID());
							}
						}
					}
				}
			}else
			{
				System.out.println("Non hai inesrito unp pianeta");
			}
			break;
		case 2: ricerca(); break;
		default: break;
		}
	}
	
	public static void calcolocentrodimassa()
	{
		
	}

   
    
    
}
